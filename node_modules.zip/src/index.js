const { v4: uuidv4 } = require("uuid");
const AWS = require("aws-sdk");
const middy = require("@middy/core");
const jsonbodyparser = require("@middy/http-json-body-parser");

const handler = async (event) => {
  const { httpMethod, path, pathParameters, body } = event;
  
  if (httpMethod === "POST" && path === "/") {
    return Addtodo(body);
  } else {
    return {
      statusCode: 404,
      body: JSON.stringify({ message: "Route not found" }),
    };
  }
};
const Addtodo = async (event) => {
  const { Todo } = event.body;
  const CreatedAt = new Date().toISOString();
  const id = uuidv4();
  const NewTodo = {
    id,
    Todo,
    CreatedAt,
    Completed: false,
  };

  const DB = new AWS.DynamoDB.DocumentClient();
  await DB.put({
    TableName: "TodoTable",
    Item: NewTodo,
  }).promise();

  console.log(NewTodo);

  return {
    statusCode: 200,
    body: JSON.stringify(NewTodo),
  };
};
const wrappedHandler = middy(handler).use(jsonbodyparser());
module.exports = {
  handler: wrappedHandler,
};
